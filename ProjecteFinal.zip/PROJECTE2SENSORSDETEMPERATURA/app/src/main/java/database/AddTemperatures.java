package database;

public class AddTemperatures {
}
