package com.example.projecte2_sensorsdetemperatura;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.ResultSet;
import java.sql.SQLException;
public class DisplayDataActivity extends AppCompatActivity {

    private TextView dataTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data);

        dataTextView = findViewById(R.id.dataTextView);

        // Fetch data from database
        DatabaseHelper.fetchData(new DatabaseHelper.OnDataFetchedListener() {
            @Override
            public void onDataFetched(ResultSet resultSet) {
                if (resultSet != null) {
                    StringBuilder data = new StringBuilder();
                    try {
                        while (resultSet.next()) {
                            String pis = resultSet.getString("pis");
                            int temperatura = resultSet.getInt("temperatura");
                            data.append("Pis: ").append(pis).append(", Temperatura: ").append(temperatura).append("\n");
                        }
                        dataTextView.setText(data.toString());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
