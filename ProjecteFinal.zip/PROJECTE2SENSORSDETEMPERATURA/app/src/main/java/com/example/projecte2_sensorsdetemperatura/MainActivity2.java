package com.example.projecte2_sensorsdetemperatura;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    EditText txtPis = null;
    EditText txtTemperatura = null;
    ListView listView;
    DataListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtPis = findViewById(R.id.txtPis);
        txtTemperatura = findViewById(R.id.txtTemperatura);
        listView = findViewById(R.id.listView);

        // Setup adapter for ListView
        adapter = new DataListAdapter(this, R.layout.list_items_layout, new ArrayList<DataModel>());
        listView.setAdapter(adapter);

        // Fetch data when activity starts
        fetchData();
    }

    public void clickRegresar(View view) {
        Intent intent = new Intent(this, data.class);
        startActivity(intent);
    }

    public void fetchData() {
        DatabaseHelper.fetchData(new DatabaseHelper.OnDataFetchedListener() {
            @Override
            public void onDataFetched(ResultSet resultSet) {
                if (resultSet != null) {
                    // Parse ResultSet and update ListView adapter
                    List<DataModel> dataModels = parseResultSet(resultSet);
                    adapter.clear();
                    adapter.addAll(dataModels);
                    adapter.notifyDataSetChanged();
                } else {
                    Log.e("FetchData", "ResultSet is null");
                    Toast.makeText(MainActivity2.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private List<DataModel> parseResultSet(ResultSet resultSet) {
        List<DataModel> dataModels = new ArrayList<>();
        try {
            while (resultSet.next()) {
                String pis = resultSet.getString("pis");
                String temperatura = resultSet.getString("temperatura");
                dataModels.add(new DataModel(pis, temperatura));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Log.e("ParseResultSet", "SQLException: " + e.getMessage());
            Toast.makeText(MainActivity2.this, "Error parsing data", Toast.LENGTH_SHORT).show();
        }
        return dataModels;
    }
}
