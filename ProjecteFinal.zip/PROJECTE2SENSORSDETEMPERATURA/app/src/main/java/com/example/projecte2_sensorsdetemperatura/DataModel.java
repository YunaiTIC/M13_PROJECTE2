package com.example.projecte2_sensorsdetemperatura;

public class DataModel {
    private String pis;
    private String temperatura;

    public DataModel(String pis, String temperatura) {
        this.pis = pis;
        this.temperatura = temperatura;
    }

    public String getPis() {
        return pis;
    }

    public String getTemperatura() {
        return temperatura;
    }
}
