package com.example.projecte2_sensorsdetemperatura;
import android.os.AsyncTask;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.Executor;

public class DatabaseHelper extends AppCompatActivity {
    private static final String URL = "jdbc:mysql://localhost:3306/temperatures";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public static void insertData(final String pis, final int temperatura) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                    String sql = "INSERT INTO temperatura (pis, temperatura) VALUES (?, ?)";
                    PreparedStatement statement = conn.prepareStatement(sql);
                    statement.setString(1, pis);
                    statement.setInt(2, temperatura);
                    statement.executeUpdate();
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }



    public static void fetchData(final OnDataFetchedListener listener) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                    String sql = "SELECT * FROM temperatura";
                    PreparedStatement statement = conn.prepareStatement(sql);
                    ResultSet resultSet = statement.executeQuery();
                    listener.onDataFetched(resultSet);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public interface OnDataFetchedListener {
        void onDataFetched(ResultSet resultSet);
    }
}
