package com.example.projecte2_sensorsdetemperatura;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.List;

public class GraphActivity extends AppCompatActivity {

    private LineChart lineChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        lineChart = findViewById(R.id.lineChart);

        fetchDataAndPopulateGraph();
    }

    private void fetchDataAndPopulateGraph() {
        DataFetcher.fetchDataFromAPI(this, new DataFetcher.DataFetchListener() {
            @Override
            public void onDataFetched(List<DataModel> dataList) {
                populateGraphWithData(dataList);
            }

            @Override
            public void onError(String errorMessage) {
                Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void populateGraphWithData(List<DataModel> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            ArrayList<Entry> entries = new ArrayList<>();
            final ArrayList<String> xAxisLabels = new ArrayList<>();

            for (int i = 0; i < dataList.size(); i++) {
                String temperaturaStr = dataList.get(i).getTemperatura();
                float temperatura = Float.parseFloat(temperaturaStr);
                entries.add(new Entry(i, temperatura));

                String pis = dataList.get(i).getPis();
                xAxisLabels.add("Pis: " + pis);
            }

            LineDataSet dataSet = new LineDataSet(entries, "");
            dataSet.setDrawCircles(true);
            dataSet.setCircleColor(Color.BLUE);
            dataSet.setLineWidth(2f);
            dataSet.setCircleRadius(4f);
            dataSet.setColor(Color.RED);
            dataSet.setValueTextSize(10f);
            dataSet.setValueTextColor(Color.BLACK);

            LineData lineData = new LineData(dataSet);
            lineChart.setData(lineData);

            lineChart.getDescription().setEnabled(false);

            // Customize X-Axis
            XAxis xAxis = lineChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setTextSize(10f);
            xAxis.setTextColor(Color.BLACK);
            xAxis.setDrawGridLines(false);
            xAxis.setDrawAxisLine(true);
            xAxis.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    return xAxisLabels.get((int) value);
                }
            });

            YAxis leftAxis = lineChart.getAxisLeft();
            leftAxis.setTextSize(15f);
            leftAxis.setTextColor(Color.BLACK);
            leftAxis.setDrawGridLines(true);

            YAxis rightAxis = lineChart.getAxisRight();
            rightAxis.setEnabled(false);

            Legend legend = lineChart.getLegend();
            legend.setEnabled(false);

            lineChart.animateX(1500);
            lineChart.animateY(1500);

            lineChart.invalidate();
        } else {
            Toast.makeText(this, "No data available for chart", Toast.LENGTH_SHORT).show();
        }
    }
}