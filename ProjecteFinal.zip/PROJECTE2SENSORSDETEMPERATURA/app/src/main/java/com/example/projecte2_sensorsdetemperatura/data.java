package com.example.projecte2_sensorsdetemperatura;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.example.projecte2_sensorsdetemperatura.MainActivity2;


import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class data extends AppCompatActivity {

    EditText txtPis = null;
    EditText txtTemperatura = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);

        //Inicialitzem els components
        txtPis = findViewById(R.id.txtPis);
        txtTemperatura = findViewById(R.id.txtTemperatura);
    }

    public void clickBtnInsertar(View view) {
        String url = "http://192.168.17.97/temperatures/insertar.php";
        RequestQueue queue = Volley.newRequestQueue(this);

        //Creem  una sol·licitud POST per enviar dades a la API.
        StringRequest resultadoPost = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), "Temperatura afegida", Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error " + error, Toast.LENGTH_LONG).show();
            }
        }) {
            // Proporciona els paràmetres que s'enviaran amb la sol·licitud POST.
            // Aquí s'obtenen els valors de txtPis i txtTemperatura,
            // i es posen en un Map de paràmetres.
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("pis", txtPis != null ? txtPis.getText().toString() : "");
                parametros.put("temperatura", txtTemperatura != null ? txtTemperatura.getText().toString() : "");

                return parametros;
            }
        };

        queue.add(resultadoPost);
    }

    public void clickVer(View view) {
        EditText txtId = findViewById(R.id.txtId);
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("id", txtId.getText().toString());
        startActivity(intent);
    }
}
