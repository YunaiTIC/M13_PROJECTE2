package com.example.projecte2_sensorsdetemperatura;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.benvinguda);


        Button afegir_temp = findViewById(R.id.add_mayo);
        afegir_temp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, data.class);
                startActivity(intent);
            }
        });
        Button NotisButton = findViewById(R.id.button4);
        NotisButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Notificaciones.class);
                startActivity(intent);
            }
        });
        Button bttn_add_mayoo = findViewById(R.id.add_mayo);
        bttn_add_mayoo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, data.class);
                startActivity(intent);
            }
        });

        // Example usage of fetchData() method
        DatabaseHelper.fetchData(new DatabaseHelper.OnDataFetchedListener() {
            @Override
            public void onDataFetched(ResultSet resultSet) {
                if (resultSet != null) {
                    try {
                        while (resultSet.next()) {
                            int pis = resultSet.getInt("pis");
                            float temperatura = resultSet.getFloat("temperatura");
                            Log.d("MainActivity", "Pis: " + pis + ", Temperatura: " + temperatura);
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });


//DATABASE BUTTON








        Button consumEnergiaButton = findViewById(R.id.consum_energia);
        consumEnergiaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GraphActivity.class);
                startActivity(intent);
            }
        });

        Button historialButton = findViewById(R.id.btn_historial);
        historialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(MainActivity.this, MostrarDatosActivity.class);
                startActivity(intent);
            }
        });





       /* Button consumEnergiaButtonn = findViewById(R.id.consum_energia);
        consumEnergiaButtonn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(MainActivity.this, ConsumEnergiaActivity.class);
                startActivity(intent);
            }
        });

        /*
        Button notificacionsButton = findViewById(R.id.button4);
        notificacionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click, you can start a new activity here
                // For example:
                Intent intent = new Intent(BenvingudaActivity.this, NotificacionsActivity.class);
                startActivity(intent);
            }
        });

         */
    }

}
