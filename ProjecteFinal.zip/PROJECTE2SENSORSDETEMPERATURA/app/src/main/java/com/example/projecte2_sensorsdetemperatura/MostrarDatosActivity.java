package com.example.projecte2_sensorsdetemperatura;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.projecte2_sensorsdetemperatura.DataListAdapter;
import com.example.projecte2_sensorsdetemperatura.DataModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MostrarDatosActivity extends AppCompatActivity {

    private ListView listView;
    private List<DataModel> dataList;
    private DataListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos);

        listView = findViewById(R.id.listView);
        dataList = new ArrayList<>();
        adapter = new DataListAdapter(this, R.layout.list_items_layout, dataList);
        listView.setAdapter(adapter);

        Button buttonShowData = findViewById(R.id.button_show_data);
        buttonShowData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchDataFromAPI();
            }
        });
    }

    private void fetchDataFromAPI() {
        String url = "http://192.168.17.97/temperatures/registro.php";
        //Es crea una nova cua de sol·licituds de Vollley
        RequestQueue queue = Volley.newRequestQueue(this);
        //Creem sol·licitud JsonArrayRequest de tipus GET per obtenir un JSONArray des de l'URL especificada.
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {

                    /*Si la resposta es correcta*/
                    @Override
                    public void onResponse(JSONArray response) {
                        processJSONResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    /*Si la resposta es incorrecta*/
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(request);
    }


    /*Procesem la resposta JSON*/
    private void processJSONResponse(JSONArray response) {
        try {
            Log.d("JSON_RESPONSE", "Resposta Rebuda: " + response.toString());
            // Mirem si la resposta esta buida, o no es compatible
            if (response == null || response.length() == 0 || !(response.get(0) instanceof JSONObject)) {
                Log.e("JSON_PARSE_ERROR", "El format JSO No es valid");
                return;
            }
            //  Recorrem cada objecte a l'array JSON i extreiem les dades de pis i temperatura, afegint-les a dataList.
            for (int i = 0; i < response.length(); i++) {
                JSONObject jsonObject = response.getJSONObject(i);
                String pis = jsonObject.getString("pis");
                String temperatura = jsonObject.getString("temperatura");
                dataList.add(new DataModel(pis, temperatura));
            }
            adapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("JSON_PARSE_ERROR", "Error de pareseig: " + e.getMessage());
        }
    }
}
