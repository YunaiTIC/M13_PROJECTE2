package com.example.projecte2_sensorsdetemperatura;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DataFetcher {

    private static final String TAG = "DataFetcher";

    public interface DataFetchListener {
        void onDataFetched(List<DataModel> dataList);
        void onError(String errorMessage);
    }

    public static void fetchDataFromAPI(Context context, final DataFetchListener listener) {
        String url = "http://192.168.17.97/temperatures/registro.php";
        RequestQueue queue = Volley.newRequestQueue(context);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        List<DataModel> dataList = parseJSONResponse(response);
                        listener.onDataFetched(dataList);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        listener.onError("Error: " + error.getMessage());
                    }
                });
        queue.add(request);
    }

    private static List<DataModel> parseJSONResponse(JSONArray response) {
        List<DataModel> dataList = new ArrayList<>();
        try {
            Log.d(TAG, "Received JSON response: " + response.toString());
            // Check if the response is empty or not a valid JSON array
            if (response == null || response.length() == 0 || !(response.get(0) instanceof JSONObject)) {
                Log.e(TAG, "Invalid JSON format");
                return dataList;
            }
            // Parse JSON array from the response
            for (int i = 0; i < response.length(); i++) {
                JSONObject jsonObject = response.getJSONObject(i);
                String pis = jsonObject.getString("pis");
                String temperatura = jsonObject.getString("temperatura");
                dataList.add(new DataModel(pis, temperatura));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(TAG, "Error parsing JSON: " + e.getMessage());
        }
        return dataList;
    }
}
