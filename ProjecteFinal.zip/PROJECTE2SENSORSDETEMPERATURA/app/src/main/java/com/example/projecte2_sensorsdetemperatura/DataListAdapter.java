package com.example.projecte2_sensorsdetemperatura;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;


/*
Heredem per a gestionar llista d'objectes DataModel i enllaçar-los amb la vista.
 */
public class DataListAdapter extends ArrayAdapter<DataModel> {

    private Context mContext;
    private int mResource;

    //Constructor
    public DataListAdapter(Context context, int resource, List<DataModel> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    //Retornem una vista per a un element en una posició específica de la llista.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(mResource, parent, false);
        }

        //Obtenim i establim els textos
        DataModel data = getItem(position);

        TextView textViewPis = convertView.findViewById(R.id.textViewPis);
        TextView textViewTemperatura = convertView.findViewById(R.id.textViewTemperatura);

        textViewPis.setText(data.getPis());
        textViewTemperatura.setText(data.getTemperatura());

        return convertView;
    }
}
