package com.example.projecte2_sensorsdetemperatura;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Notificaciones extends AppCompatActivity {

    private ListView listView;
    private List<DataModel> dataList;
    private DataListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_mostrar_datos);
        setContentView(R.layout.activity_notifications_tab);

        listView = findViewById(R.id.listView2);
        dataList = new ArrayList<>();
        adapter = new DataListAdapter(this, R.layout.list_items_layout, dataList);
        listView.setAdapter(adapter);

        fetchDataFromAPI();
    }

    private void fetchDataFromAPI() {
        String url = "http://192.168.17.97/temperatures/registro.php";
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        processJSONResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(request);
    }

    private void processJSONResponse(JSONArray response) {
        try {
            Log.d("JSON_RESPONSE", "Received JSON response: " + response.toString());
            // Clear the existing data list
            dataList.clear();

            // Parse JSON array from the response
            for (int i = 0; i < response.length(); i++) {
                JSONObject jsonObject = response.getJSONObject(i);
                String pis = jsonObject.getString("pis");
                String temperatura = jsonObject.getString("temperatura");
                // Add data to the list only if it meets the threshold conditions
                if (isTemperatureExceedingThreshold(temperatura)) {
                    dataList.add(new DataModel(pis, temperatura));
                }
            }
            // Notify the adapter that the data set has changed
            adapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("JSON_PARSE_ERROR", "Error parsing JSON: " + e.getMessage());
        }
    }

    // Check if the temperature exceeds the threshold
    private boolean isTemperatureExceedingThreshold(String temperatura) {
        double temp = Double.parseDouble(temperatura);
        return temp > 30 || temp < 15;
    }
}
